create definer = root@localhost view film_category_actor as
select `sakila`.`film`.`title`       AS `Title`,
       `sakila`.`film`.`description` AS `Description`,
       `sakila`.`category`.`name`    AS `Category`,
       `sakila`.`film`.`rental_rate` AS `Price`,
       `sakila`.`film`.`length`      AS `Length`,
       `sakila`.`film`.`rating`      AS `Rating`,
       `sakila`.`actor`.`first_name` AS `First name`,
       `sakila`.`actor`.`last_name`  AS `Last name`
from ((((`sakila`.`category` left join `sakila`.`film_category` on ((`sakila`.`category`.`category_id` =
                                                                     `sakila`.`film_category`.`category_id`))) left join `sakila`.`film` on ((`sakila`.`film_category`.`film_id` = `sakila`.`film`.`film_id`))) join `sakila`.`film_actor` on ((`sakila`.`film`.`film_id` = `sakila`.`film_actor`.`film_id`)))
       join `sakila`.`actor` on ((`sakila`.`film_actor`.`actor_id` = `sakila`.`actor`.`actor_id`)))
group by `sakila`.`actor`.`actor_id`;

