create definer = root@localhost view noviview as
select `film_list`.`title`                    AS `title`,
       `film_list`.`description`              AS `description`,
       `film_list`.`length`                   AS `length`,
       `film_list`.`rating`                   AS `rating`,
       `sales_by_film_category`.`category`    AS `category`,
       `sales_by_film_category`.`total_sales` AS `total_sales`
from (`sakila`.`film_list`
       join `sakila`.`sales_by_film_category` on ((`film_list`.`category` = `sales_by_film_category`.`category`)))
order by `sales_by_film_category`.`total_sales`;

